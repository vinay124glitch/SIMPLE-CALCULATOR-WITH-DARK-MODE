let display = document.getElementById('display');
const themeSwitch = document.getElementById('theme-switch');
const themeLabel = document.getElementById('theme-label');

function append(value) {
  display.value += value;
}

function clearDisplay() {
  display.value = '';
}

function deleteLast() {
  display.value = display.value.slice(0, -1);
}

function calculate() {
  try {
    display.value = eval(display.value);
  } catch {
    display.value = 'Error';
  }
}

themeSwitch.addEventListener('change', () => {
  document.body.classList.toggle('dark');
  themeLabel.textContent = themeSwitch.checked ? 'Light Mode' : 'Dark Mode';
});
